import { TestBed } from '@angular/core/testing';
import { HeroService } from './hero.service';
import { MessageService } from './message.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable,of, throwError } from 'rxjs';
import { Hero } from './hero';

// create a function into global context for Jest
global.console.error = jest.fn();

jest.mock('./message.service');
jest.mock('@angular/common/http');

describe('HeroService', () => {
  let service: HeroService;
  let mockHeros: Hero[];
  const backendUrl: String = 'api/heroes';
  let mockMessageService: MessageService;
  let mockHttpClient;
  let spyHandleError;

  beforeAll(() => {
    mockHeros= [{name:"n1",id:1},{name:"n2",id:2}];
    
  });

  beforeEach(() => {
    mockMessageService = new MessageService();
    mockHttpClient = new HttpClient(null);
    TestBed.configureTestingModule({providers: [{provide: MessageService , useValue: mockMessageService}, {provide: HttpClient , useValue: mockHttpClient}]});
    service = TestBed.get(HeroService);
  });

  it('HeroService should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getHeroes method returns all heroes from backend service', () => {
    //setup mock response from api
    mockHttpClient.get.mockReturnValueOnce(of(mockHeros));
    //fail the test if mockHeros is not returned
    service.getHeroes().subscribe(heros => expect(heros).toEqual(mockHeros),fail);
    //HttpClient.get is called with correct url
    expect(mockHttpClient.get).toHaveBeenCalledWith(backendUrl);
    expect(mockHttpClient.get).toHaveBeenCalledTimes(1);
    //check if correct message is being logged
    expect(mockMessageService.add).toHaveBeenCalledTimes(1);
    expect(mockMessageService.add).toHaveBeenCalledWith('HeroService: fetched heroes');
  });

  it('getHeroes 404', () => {
    //mocked 404 error response
    const errorResponse = new Error('test 404 error');
    //setup mock response from api
    mockHttpClient.get.mockReturnValueOnce(throwError(errorResponse));
    //fail the test if subscribe returns empty array
    service.getHeroes().subscribe(heros => expect(heros).toEqual([]),fail);
    //HttpClient.get is called with correct url
    expect(mockHttpClient.get).toHaveBeenCalledWith(backendUrl);
    expect(mockHttpClient.get).toHaveBeenCalledTimes(1);
    //check if correct message is being logged
    expect(global.console.error).toHaveBeenCalledTimes(1);
    expect(global.console.error).toHaveBeenCalledWith(errorResponse);
    expect(mockMessageService.add).toHaveBeenCalledTimes(1);
    expect(mockMessageService.add).toHaveBeenCalledWith('HeroService: getHeroes failed: test 404 error');
  });

});
